                      =================================
                      Star Wars: The POV-Ray Collection
                      =================================

'Star Wars: The POV-Ray Collection' is an archive of images and 3D model 
files depicting vehicles, weapons and objects from the Star Wars universe. All 
3D model files are intended specifically for use with the Persistence of Vision 
Ray-Tracer (POV-Ray) v3.0 or higher. Unless otherwise indicated, all images 
on this site were produced using POV-Ray.

'Star Wars' and all associated trademarks, images and designs, including the 
designs of the vehicles and objects depicted in this archive except where 
otherwise indicated, are copyright (c) 1997 Lucasfilm Ltd, and are used here 
without permission. 'POV-Ray' and all associated trademarks are copyright 
(c) 1991-1997 the POV-Ray Team. 'Star Wars: The POV-Ray Collection' is in no 
way affiliated with either Lucasfilm Ltd. or the POV-Ray team.

The copyright on all original intellectual material within this archive is owned by 
the author of the material in question. Please see the accompanying documentation 
files for each model for further details.

CONDITIONS OF USE:

The material contained within this archive may be freely downloaded, distributed, 
altered or modified subject to the following restrictions:

1) The use of any of this material for commercial gain or profit is strictly 
forbidden. It is provided for personal use only, and for the enjoyment of the 
ray-tracing community at large. 

2) Images created using these model files may be distributed as long as the 
original author is credited - if you want to make images using my models, go 
ahead, just make it clear which bits are my work and which bits are yours. 
Likewise, if you want to distribute modified versions of these models, please 
indicate which bits are the original author's work and which bits are your own 
modifications.

3) The images contained within this archive may be freely distributed but they may 
not be altered. If you want to trace your own images, get hold of POV-Ray, download 
the models and do it that way - please don't mess around with other people's pictures.

4) 'Star Wars' and all associated designs are copyright (c) 1997 Lucasfilm Ltd. 
They are used here in good faith, without permission. If you think anything on this 
site constitutes a breach of your own copyright, please contact me and it will be 
removed.