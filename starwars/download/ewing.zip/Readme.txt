(Remember, EVERYTHING has a default so you don't have to declare a 
single thing.  The following are just ones I recommend you declare 
to get the best results.)

Usage:

#declare Height = [desired height]
#declare Gender = [1=male,2=female]
#declare Breasts = [breast size]
                   Keep between 8/16 and 12/16 (or 0.5 to 0.75.
                   10/16 is best, which is the default.
[Body part rotations]
(Check "rotation.inc" for a list of rotation names and usage.)

#include "person.inc"
object{ Person

  Transformations go in here.  Any textures should be pre-declared
  before you include "person.inc".  Refer to "texture.inc" for declare
  names to use.  Use the names within the #ifndef() statements.  Most
  of the names are self explanatory.

}



I know the documentation isn't very good, so if you have any questions
at all, just email me at:  mroreo123@juno.com
Do NOT attach any files.  If you want to attach any files, contact me
for the proper email address.  (Juno can't handle file attachments.)